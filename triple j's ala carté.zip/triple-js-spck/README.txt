TRIPLE J'S ALA CARTÉ — SPCK PROJECT

1. Extract this ZIP file on your Android device.
2. In SPCK Editor, create/open a project folder named triple-js-spck.
3. Add these files: index.html, style.css, app.js.
4. Put each file's contents in the matching file.
5. Open index.html and tap Preview.

Features: dashboard, POS cart and checkout, menu CRUD, receipts, print/save receipt, JSON backup.
Data is saved in this browser's localStorage. Export backups regularly.

Limitations: This is a browser-based starter app, not the original Lovable project or an APK.
No cloud sync, staff login, inventory, payment gateway, or tax setup is included yet.
A preview/PWA is not an installable native Android APK.
